"""
gitosis -- software for hosting git repositories
"""
